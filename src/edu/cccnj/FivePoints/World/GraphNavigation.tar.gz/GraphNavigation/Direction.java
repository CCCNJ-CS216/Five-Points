package edu.cccnj.FivePoints.World.GraphNavigation;

/**
 * Direction is a simple enum for basic directions.
 */
public enum Direction {
    Up,
    Down,
    Left,
    Right
}